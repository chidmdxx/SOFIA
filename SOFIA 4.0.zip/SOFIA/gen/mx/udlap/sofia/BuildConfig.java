/** Automatically generated file. DO NOT MODIFY */
package mx.udlap.sofia;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}